/**
 * Created by serviestudios on 28/01/16.
 */
'use strict';
var globalModoDespligeApp = 0;
var IsyplusApp = angular.
    module('isyplus', [
        'ui.router',
        'ngMask',
        'ui.grid',
        'ui.grid.edit',
        'ui.grid.selection',
        'ui.grid.autoResize',
        'ui.grid.cellNav',
        'ui.grid.pinning',
        'ui.grid.resizeColumns',
        'ngResource',
        'ngDraggable']);
//Editado

