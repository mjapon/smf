(function(){
    'use strict';
    angular.module("isyplus")
        .controller("HomeCntrl", HomeCntrl);

    function HomeCntrl($scope, $state) {
        var vm = $scope;

        init();

        vm.goFormIngreso = goFormIngreso;
        vm.goUsuarios = goUsuarios;
        vm.goEmpresa = goEmpresa;
        vm.goContribs = goContribs;
        vm.goAuts = goAuts;
        vm.goJobs = goJobs;

        function init(){
            console.log("Init home cntrl");
        }

        function goFormIngreso(){
            $state.go("login");
        }

        function goUsuarios() {
            $state.go("usuarios");
        }

        function logout(){
            console.log("logout");
        }

        function goEmpresa(){
            $state.go("empresa");
        }

        function goContribs(){
            $state.go("contribs_list");
        }

        function goAuts() {
            $state.go("auts_list");
        }

        function goJobs(){
            $state.go("job_list");
        }
    }
})();

